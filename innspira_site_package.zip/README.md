# INNSPIRA 2025 - Proyecto Fotoluminiscente
Archivos listos para publicar en GitHub Pages.

Archivos incluidos:
- index.html (sitio web)
- banner.png (imagen header)
- step1_create_repo.png
- step2_add_file.png
- step3_commit.png
- step4_pages.png

Instrucciones rápidas:
1. Crear repositorio público llamado `innspira-2025`.
2. Subir estos archivos (puedes arrastrar desde el ZIP).
3. Activar GitHub Pages en Settings -> Pages, branch `main`.
